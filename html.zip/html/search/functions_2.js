var searchData=
[
  ['nummay_0',['NumMay',['../ejercicio1_01_01_d_x_8cpp.html#af32cd6c4106cd8060520f533584a414d',1,'ejercicio1  DX.cpp']]],
  ['nummen_1',['NumMen',['../ejercicio1_01_01_d_x_8cpp.html#a9410ec3fa974d1b8f2cf92671fc8a197',1,'ejercicio1  DX.cpp']]]
];
