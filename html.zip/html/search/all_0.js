var searchData=
[
  ['ano_0',['ano',['../ejercicio2_01_01_d_x_8cpp.html#ac404d93cbf0169fd9e89edc17d0c5572',1,'ejercicio2  DX.cpp']]],
  ['anoac_1',['anoac',['../ejercicio2_01_01_d_x_8cpp.html#aab9d8dc573fe2c872e487f13399bac99',1,'ejercicio2  DX.cpp']]],
  ['anos_2',['anos',['../ejercicio2_01_01_d_x_8cpp.html#aecf42cb50d397b481cbf4351ac9ef1ca',1,'ejercicio2  DX.cpp']]]
];
