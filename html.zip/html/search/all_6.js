var searchData=
[
  ['pedirfecha_0',['PedirFecha',['../ejercicio2_01_01_d_x_8cpp.html#a0bb95742d037dbcfd00061e5c6b558b2',1,'ejercicio2  DX.cpp']]],
  ['pedirn_1',['PedirN',['../ejercicio3_01_d_x_8cpp.html#a8bd092f27d7b7370df43c3bdcf6c98b3',1,'ejercicio3 DX.cpp']]],
  ['pedirnum_2',['PedirNum',['../ejercicio1_01_01_d_x_8cpp.html#a009d98f327f4421eb64e7ab8b9b58319',1,'ejercicio1  DX.cpp']]]
];
