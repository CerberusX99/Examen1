var searchData=
[
  ['calcular_0',['Calcular',['../ejercicio2_01_01_d_x_8cpp.html#a478fb9d30a2bde052b4e9796d282071f',1,'ejercicio2  DX.cpp']]]
];
